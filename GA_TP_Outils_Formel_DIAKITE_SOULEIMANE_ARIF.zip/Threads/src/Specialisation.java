public class Specialisation {
    private boolean CodeUVerif;
    private boolean MDPVerif;

    public Specialisation(boolean carteVerif, boolean codeVerif) {
        CodeUVerif = carteVerif;
        MDPVerif = codeVerif;
    }

    public boolean isCarteVerif() {
        return CodeUVerif;
    }

    public boolean isCodeVerif() {
        return MDPVerif;
    }
}

