public class Etats {
    enum States {
        CodeUtilisateur, MotdDP, VerifMDP, AccesAutorise, AccesRefuse, AlarmeDeclenchee;}
        private States states;

    public Etats(){
            this.states = States.CodeUtilisateur;
        }
        public void VerifCodeU(boolean VerifCodeU){
            System.out.println("Vérifiction du code en cours...");
            if(VerifCodeU==true) {
                this.states = States.VerifMDP;
            }
            else {
                this.states=States.AccesRefuse;

            }
        }
        public void verifMDP(boolean verifMDP){
            System.out.println("Vérification du mode de passe en cours...");
            if (this.states==States.VerifMDP){
                if (verifMDP==true){
                    System.out.println("Accès autorisé, ouverture des portes...");
                    this.states=States.AccesAutorise;
                }
                else {
                    this.states=States.AccesRefuse;
                }
            }
        }
    public void Alarme(){
        this.states = States.AlarmeDeclenchee;
    }

    public States getEtat() {
        return states;
    }

    public void setStates(States states) {
        this.states = states;
    }
}


