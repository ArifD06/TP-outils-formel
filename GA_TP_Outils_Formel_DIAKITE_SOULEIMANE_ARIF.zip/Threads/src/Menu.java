import java.util.Scanner;

public class Menu {
    private static final int TrueNumUtil = 2006;
    private static final int TrueMDP = 0001;

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int compt = 0;
        boolean accessGranted = false;

        while (compt < 3 && !accessGranted) {
            System.out.println("Entrez votre numéro code d'utilisateur: ");
            int NumCarte = scanner.nextInt();
            System.out.println("Entrez le Mot de passe : ");
            int CodeSecret = scanner.nextInt();
            System.out.println("Vérificatin en cours...");
            boolean VerifCarte = (NumCarte == TrueNumUtil);
            boolean VerifCode = (CodeSecret == TrueMDP);

            if (VerifCarte && VerifCode) {
                System.out.println("Accès accordé");

            System.out.println("Ouvrture des portes....");
                accessGranted = true;
            } else {
                compt++;
                System.out.println("Accès refusé");
                if (compt < 3) {
                    System.out.println("Tentatives restantes : " + (3 - compt));
                } else {
                    System.out.println("Trop de tentatives échouées. Déclenchement de l'alarme dans :");
                    for (int i = 10; i >= 1; i--) {
                                System.out.println(i+" seconde");

                                try {
                                    Thread.sleep(1000);
                                }

                                catch (InterruptedException e) {
                                    e.printStackTrace();

                                }

                            }
                    System.out.println("Alarme declenchée!");

                }

                            }

                        }
                    }


                }







